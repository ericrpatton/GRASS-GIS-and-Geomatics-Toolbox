/*
 *  r.in.mb
 *
 *  Calculates univariate statistics from the non-null cells of a GRASS  
 *  raster map
 *
 *   Copyright 2006 by M. Hamish Bowman, and The GRASS Development Team
 *   Author: M. Hamish Bowman, University of Otago, Dunedin, New Zealand
 *
 *   Extended 2007 by Volker Wichmann to support the aggregate functions
 *   median, percentile, skewness and trimmed mean
 * 
 *   Extended in 2008/2009 from r.in.xyz by Bob Covill to use mbio library 
 *   from MB-System. Instead of reading XYZ ASCII file, reads mb-list style
 *   file as supported by MB-System
 *
 *   This program is free software licensed under the GPL (>=v2).
 *   Read the COPYING file that comes with GRASS for details.
 *
 *   This program is intended as a replacement for the GRASS 5 s.cellstats module.
 */

#include <grass/config.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <sys/types.h>
#include <grass/gis.h>
#include <grass/glocale.h>
#include <grass/gprojects.h>
#include "local_proto.h"

#include "mb_status.h"
#include "mb_format.h"
#include "mb_define.h"
#include "mb_io.h"
#include "mb_info.h"

struct node
{
    int next;
    double z;
};

/* gridded data type */
#define MBGRID_DATA_BATHYMETRY  1
#define MBGRID_DATA_TOPOGRAPHY  2
#define MBGRID_DATA_AMPLITUDE   3
#define MBGRID_DATA_SIDESCAN    4

#define	SIZE_INCREMENT 10
#define MB_OVERLAP 2 /* 2% expansion of mb bounds */

int num_nodes = 0;
int max_nodes = 0;
struct node *nodes;

struct pj_info iproj;		/* input map proj parameters  */
struct pj_info oproj;		/* output map proj parameters  */

static void fill_map(char *, char *, double, int);

static int size;
static int count;
static int (*neighbors)[2];

typedef int metric_fn(int, int);

static int distance_euclidian_squared(int dx, int dy)
{
        return dx * dx + dy * dy;
}

static void setup_neighbors(double radius, int limit, metric_fn *dist)
{
        int i, dx, dy;
        int n;

        size = (int) radius;

        n = size * 2 + 1;

        neighbors = G_malloc(n * n * 2 * sizeof(int));

        count = 0;

        for (i = 1; i <= limit; i++)
        {
                for (dy = -size; dy <= size; dy++)
                {
                        for (dx = -size; dx <= size; dx++)
                        {
                                if ((*dist)(dx, dy) != i)
                                        continue;

                                neighbors[count][0] = dx;
                                neighbors[count][1] = dy;
                                count++;
                        }
                }
        }
}

static void setup_neighbors_euclidian(double radius)
{
        int r2 = (int) (radius * radius);

        setup_neighbors(radius, r2, distance_euclidian_squared);
}


int new_node(void)
{
    int n = num_nodes++;

    if (num_nodes >= max_nodes) {
	max_nodes += SIZE_INCREMENT;
	nodes = G_realloc(nodes, max_nodes * sizeof(struct node));
    }

    return n;
}


/* add node to sorted, single linked list 
 * returns id if head has to be saved to index array, otherwise -1 */
int add_node(int head, double z)
{
    int node_id, last_id, newnode_id, head_id;

    head_id = head;
    node_id = head_id;
    last_id = head_id;

    while (node_id != -1 && nodes[node_id].z < z) {
	last_id = node_id;
	node_id = nodes[node_id].next;
    }

    /* end of list, simply append */
    if (node_id == -1) {
	newnode_id = new_node();
	nodes[newnode_id].next = -1;
	nodes[newnode_id].z = z;
	nodes[last_id].next = newnode_id;
	return -1;
    }
    else if (node_id == head_id) {	/* pole position, insert as head */
	newnode_id = new_node();
	nodes[newnode_id].next = head_id;
	head_id = newnode_id;
	nodes[newnode_id].z = z;
	return (head_id);
    }
    else {			/* somewhere in the middle, insert */
	newnode_id = new_node();
	nodes[newnode_id].z = z;
	nodes[newnode_id].next = node_id;
	nodes[last_id].next = newnode_id;
	return -1;
    }
}


void get_geo_bounds(struct Cell_head, double[4]);


int main(int argc, char *argv[])
{

    FILE *in_fp;
    int out_fd;
    char *infile, *outmap, outmap_tmp[120];
    int xcol, ycol, zcol, max_col, percent;
    int do_zfilter;
    int method = -1;
    int bin_n, bin_min, bin_max, bin_sum, bin_sumsq, bin_index;
    double zrange_min, zrange_max, d_tmp;
    char *fs;			/* field delim */
    off_t filesize;
    int linesize, estimated_lines;
    int from_stdin;
    int can_seek;

    /* Proj stuff */
    struct Key_Value *in_proj_info, *in_unit_info;
    struct Key_Value *out_proj_info, *out_unit_info;
    char dum[100];
    double longitude, latitude;
    double rast_val;

    /* MB stuff */
    int ib;
    void *datalist;
    int look_processed = MB_DATALIST_LOOK_UNSET;
    int status = MB_SUCCESS;
    int verbose = 0;
    int formatread;
    struct mb_info_struct mb_info;
    int lonflip;
    int error = MB_ERROR_NO_ERROR;
    int pstatus;
    char path[MB_PATH_MAXLINE];
    char ppath[MB_PATH_MAXLINE];
    char rfile[MB_PATH_MAXLINE];
    char file[MB_PATH_MAXLINE];
    char *message = NULL;
    int format;
    int rformat;
    int pings;
    int btime_i[7];
    int etime_i[7];
    double btime_d;
    double etime_d;
    int datatype = MBGRID_DATA_BATHYMETRY;
    double file_weight;
    double speedmin;
    double timegap;
    int beams_bath;
    int beams_amp;
    int pixels_ss;
    int beams_all;
    double bounds[4];		/* region */
    int file_in_bounds;
    void *mbio_ptr = NULL;
    struct mb_io_struct *mb_io_ptr = NULL;

    int rpings;
    int kind;
    int time_i[7];
    double time_d;
    double navlon;
    double navlat;
    double speed;
    double heading;
    double distance;
    double altitude;
    double sonardepth;
    char *beamflag = NULL;
    double *bath = NULL;
    double *bathlon = NULL;
    double *bathlat = NULL;
    double *amp = NULL;
    double *ss = NULL;
    double *sslon = NULL;
    double *sslat = NULL;
    char comment[MB_COMMENT_MAXLINE];

    RASTER_MAP_TYPE rtype;
    struct History history;
    char title[64];
    void *n_array, *min_array, *max_array, *sum_array, *sumsq_array,
	*index_array;
    void *raster_row, *ptr;
    struct Cell_head region;
    struct Cell_head window;
    int rows, cols;		/* scan box size */
    int row, col;		/* counters */
    int zz, zzz;
    int fill_cnt = 0;
    int fill_size = 7;
    int fill_start = (fill_size / 2) * -1;

    int pass, npasses, line;
    char buff[BUFFSIZE];
    double x, y, z;
    double x_nadir, y_nadir;
    double cross_dist = 0.0;
    char **tokens;
    int ntokens;		/* number of tokens */
    double pass_north, pass_south;
    int arr_row, arr_col, count, count_total, cnt_file;

    double min = 0.0 / 0.0;	/* init as nan */
    double max = 0.0 / 0.0;	/* init as nan */
    double zscale = 1.0;
    size_t offset, n_offset;
    int n = 0;
    double sum = 0.;
    double sumsq = 0.;
    double variance, mean, skew, sumdev;
    int pth = 0;
    double trim = 0.0;

    int j, k;
    int head_id, node_id;
    int r_low, r_up;

    struct GModule *module;
    struct Option *input_opt, *output_opt, *percent_opt, *type_opt;
    struct Option *method_opt, *zrange_opt, *zscale_opt, *fill_opt;
    struct Option *trim_opt, *pth_opt, *width_opt;
    struct Flag *sidescan_flag, *shell_style, *skipline, *amp_flag;

    G_gisinit(argv[0]);

    module = G_define_module();
    module->keywords = _("raster, import, LIDAR, Multibeam");
    module->description =
	_("Create a raster map from mbio compatible multibeam data using univariate statistics.");

    input_opt = G_define_standard_option(G_OPT_F_INPUT);
    input_opt->description = _("MB-System style list-file");

    output_opt = G_define_standard_option(G_OPT_R_OUTPUT);

    method_opt = G_define_option();
    method_opt->key = "method";
    method_opt->type = TYPE_STRING;
    method_opt->required = NO;
    method_opt->description = _("Statistic to use for raster values");
    method_opt->options =
	"n,min,max,range,sum,mean,stddev,variance,coeff_var,median,percentile,skewness,trimmean";
    method_opt->answer = "mean";
    method_opt->guisection = _("Statistic");

    type_opt = G_define_option();
    type_opt->key = "type";
    type_opt->type = TYPE_STRING;
    type_opt->required = NO;
    type_opt->options = "CELL,FCELL,DCELL";
    type_opt->answer = "FCELL";
    type_opt->description = _("Storage type for resultant raster map");

    width_opt = G_define_option();
    width_opt->key = "width";
    width_opt->type = TYPE_DOUBLE;
    width_opt->required = NO;
    width_opt->key_desc = "width";
    width_opt->description = _("Restrict data by acrosstrack distance (Max)");

    zrange_opt = G_define_option();
    zrange_opt->key = "zrange";
    zrange_opt->type = TYPE_DOUBLE;
    zrange_opt->required = NO;
    zrange_opt->key_desc = "min,max";
    zrange_opt->description = _("Filter range for z data (min,max)");

    zscale_opt = G_define_option();
    zscale_opt->key = "zscale";
    zscale_opt->type = TYPE_DOUBLE;
    zscale_opt->required = NO;
    zscale_opt->answer = "1.0";
    zscale_opt->key_desc = "zscale";
    zscale_opt->description = _("Scale to apply to z data");

    fill_opt = G_define_option();
    fill_opt->key = "fill";
    fill_opt->type = TYPE_INTEGER;
    fill_opt->required = NO;
    fill_opt->answer = "3";
    fill_opt->description = _("Fill nulls in x size neighbourhood");

    percent_opt = G_define_option();
    percent_opt->key = "percent";
    percent_opt->type = TYPE_INTEGER;
    percent_opt->required = NO;
    percent_opt->answer = "100";
    percent_opt->options = "1-100";
    percent_opt->description = _("Percent of map to keep in memory");

    pth_opt = G_define_option();
    pth_opt->key = "pth";
    pth_opt->type = TYPE_INTEGER;
    pth_opt->required = NO;
    pth_opt->options = "1-100";
    pth_opt->description = _("pth percentile of the values");
    pth_opt->guisection = _("Statistic");

    trim_opt = G_define_option();
    trim_opt->key = "trim";
    trim_opt->type = TYPE_DOUBLE;
    trim_opt->required = NO;
    trim_opt->options = "0-50";
    trim_opt->description =
	_("Discard <trim> percent of the smallest and <trim> percent of the largest observations");
    trim_opt->guisection = _("Statistic");

    shell_style = G_define_flag();
    shell_style->key = 'g';
    shell_style->description =
	_("In scan mode, print using shell script style");

    skipline = G_define_flag();
    skipline->key = 'i';
    skipline->description = _("Ignore broken lines");

    amp_flag = G_define_flag();
    amp_flag->key = 'a';
    amp_flag->description = _("Use amplitude (default = bathymetry)");

    sidescan_flag = G_define_flag();
    sidescan_flag->key = 's';
    sidescan_flag->description = _("Use sidescan (default = bathymetry)");

    if (G_parser(argc, argv))
	exit(EXIT_FAILURE);


    /* parse input values */
    infile = input_opt->answer;
    outmap = output_opt->answer;	/* get current default values */
    sprintf(outmap_tmp, "%s_tmp", outmap);

    /* get current default values */
    status = mb_defaults(verbose, &format, &pings, &lonflip, bounds,
			 btime_i, etime_i, &speedmin, &timegap);

    formatread = -1;
    status = mb_get_info_datalist(verbose, infile, &formatread,
				  &mb_info, lonflip, &error);

    if (amp_flag->answer)
	datatype = MBGRID_DATA_AMPLITUDE;

    if (sidescan_flag->answer)
	datatype = MBGRID_DATA_SIDESCAN;

    if (status = mb_datalist_open(verbose, &datalist,
				  infile, look_processed,
				  &error) != MB_SUCCESS) {
	error = MB_ERROR_OPEN_FAIL;
	fprintf(stderr, "\nUnable to open data list file: %s\n", infile);
	mb_memory_clear(verbose, &error);
	exit(error);
    }


    percent = atoi(percent_opt->answer);
    zscale = atof(zscale_opt->answer);

    fill_size = atoi(fill_opt->answer);
    fill_start = (fill_size / 2) * -1;

    /* parse zrange */
    do_zfilter = FALSE;
    if (zrange_opt->answer != NULL) {	/* should this be answerS ? */
	sscanf(zrange_opt->answers[0], "%lf", &zrange_min);
	sscanf(zrange_opt->answers[1], "%lf", &zrange_max);
	do_zfilter = TRUE;

	if (zrange_min > zrange_max) {
	    d_tmp = zrange_max;
	    zrange_max = zrange_min;
	    zrange_min = d_tmp;
	}
    }

    /* figure out what maps we need in memory */
    /*  n               n
       min              min
       max              max
       range            min max         max - min
       sum              sum
       mean             sum n           sum/n
       stddev           sum sumsq n     sqrt((sumsq - sum*sum/n)/n)
       variance         sum sumsq n     (sumsq - sum*sum/n)/n
       coeff_var        sum sumsq n     sqrt((sumsq - sum*sum/n)/n) / (sum/n)
       median           n               array index to linked list
       percentile       n               array index to linked list
       skewness         n               array index to linked list
       trimmean         n               array index to linked list
     */
    bin_n = FALSE;
    bin_min = FALSE;
    bin_max = FALSE;
    bin_sum = FALSE;
    bin_sumsq = FALSE;
    bin_index = FALSE;

    if (strcmp(method_opt->answer, "n") == 0) {
	method = METHOD_N;
	bin_n = TRUE;
    }
    if (strcmp(method_opt->answer, "min") == 0) {
	method = METHOD_MIN;
	bin_min = TRUE;
    }
    if (strcmp(method_opt->answer, "max") == 0) {
	method = METHOD_MAX;
	bin_max = TRUE;
    }
    if (strcmp(method_opt->answer, "range") == 0) {
	method = METHOD_RANGE;
	bin_min = TRUE;
	bin_max = TRUE;
    }
    if (strcmp(method_opt->answer, "sum") == 0) {
	method = METHOD_SUM;
	bin_sum = TRUE;
    }
    if (strcmp(method_opt->answer, "mean") == 0) {
	method = METHOD_MEAN;
	bin_sum = TRUE;
	bin_n = TRUE;
    }
    if (strcmp(method_opt->answer, "stddev") == 0) {
	method = METHOD_STDDEV;
	bin_sum = TRUE;
	bin_sumsq = TRUE;
	bin_n = TRUE;
    }
    if (strcmp(method_opt->answer, "variance") == 0) {
	method = METHOD_VARIANCE;
	bin_sum = TRUE;
	bin_sumsq = TRUE;
	bin_n = TRUE;
    }
    if (strcmp(method_opt->answer, "coeff_var") == 0) {
	method = METHOD_COEFF_VAR;
	bin_sum = TRUE;
	bin_sumsq = TRUE;
	bin_n = TRUE;
    }
    if (strcmp(method_opt->answer, "median") == 0) {
	method = METHOD_MEDIAN;
	bin_index = TRUE;
    }
    if (strcmp(method_opt->answer, "percentile") == 0) {
	if (pth_opt->answer != NULL)
	    pth = atoi(pth_opt->answer);
	else
	    G_fatal_error(_("Unable to calculate percentile without the pth option specified!"));
	method = METHOD_PERCENTILE;
	bin_index = TRUE;
    }
    if (strcmp(method_opt->answer, "skewness") == 0) {
	method = METHOD_SKEWNESS;
	bin_index = TRUE;
    }
    if (strcmp(method_opt->answer, "trimmean") == 0) {
	if (trim_opt->answer != NULL)
	    trim = atof(trim_opt->answer) / 100.0;
	else
	    G_fatal_error(_("Unable to calculate trimmed mean without the trim option specified!"));
	method = METHOD_TRIMMEAN;
	bin_index = TRUE;
    }

    if (strcmp("CELL", type_opt->answer) == 0)
	rtype = CELL_TYPE;
    else if (strcmp("DCELL", type_opt->answer) == 0)
	rtype = DCELL_TYPE;
    else
	rtype = FCELL_TYPE;

    if (method == METHOD_N)
	rtype = CELL_TYPE;

    G_get_window(&window);

    if ((G_projection() != PROJECTION_LL) && window.proj != 0) {
	if ((in_proj_info = G_get_projinfo()) == NULL)
	    G_fatal_error(_("Can't get projection info of current location"));

	if ((in_unit_info = G_get_projunits()) == NULL)
	    G_fatal_error(_("Can't get projection units of current location"));

	if (pj_get_kv(&iproj, in_proj_info, in_unit_info) < 0)
	    G_fatal_error(_("Can't get projection key values of current location"));

	/*  output projection to lat/long  and wgs84 ellipsoid */
	out_proj_info = G_create_key_value();
	out_unit_info = G_create_key_value();

	G_set_key_value("proj", "ll", out_proj_info);

	if (G_get_datumparams_from_projinfo(in_proj_info, buff, dum) < 0)
	    G_fatal_error(_("WGS84 output not possible as this location does not contain "
			   "datum transformation parameters. Try running g.setproj."));
	else
	    G_set_key_value("datum", "wgs84", out_proj_info);

	G_set_key_value("unit", "degree", out_unit_info);
	G_set_key_value("units", "degrees", out_unit_info);
	G_set_key_value("meters", "1.0", out_unit_info);

	if (pj_get_kv(&oproj, out_proj_info, out_unit_info) < 0)
	    G_fatal_error(_("Unable to update lat/long projection parameters"));


	G_free_key_value(in_proj_info);
	G_free_key_value(in_unit_info);
	G_free_key_value(out_proj_info);
	G_free_key_value(out_unit_info);


    }


    /* Get real GRASS Region */
    G_get_window(&region);
    rows = (int)(region.rows * (percent / 100.0));
    cols = region.cols;

    G_debug(2, "region.n=%f  region.s=%f  region.ns_res=%f", region.north,
	    region.south, region.ns_res);
    G_debug(2, "region.rows=%d  [box_rows=%d]  region.cols=%d", region.rows,
	    rows, region.cols);

    npasses = (int)ceil(1.0 * region.rows / rows);


	/* allocate memory (test for enough before we start) */
	if (bin_n)
	    n_array = G_calloc(rows * (cols + 1), G_raster_size(CELL_TYPE));
	if (bin_min)
	    min_array = G_calloc(rows * (cols + 1), G_raster_size(rtype));
	if (bin_max)
	    max_array = G_calloc(rows * (cols + 1), G_raster_size(rtype));
	if (bin_sum)
	    sum_array = G_calloc(rows * (cols + 1), G_raster_size(rtype));
	if (bin_sumsq)
	    sumsq_array = G_calloc(rows * (cols + 1), G_raster_size(rtype));
	if (bin_index)
	    index_array =
		G_calloc(rows * (cols + 1), G_raster_size(CELL_TYPE));

	/* and then free it again */
	if (bin_n)
	    G_free(n_array);
	if (bin_min)
	    G_free(min_array);
	if (bin_max)
	    G_free(max_array);
	if (bin_sum)
	    G_free(sum_array);
	if (bin_sumsq)
	    G_free(sumsq_array);
	if (bin_index)
	    G_free(index_array);

	/** end memory test **/

    /* open output map */
    out_fd = G_open_raster_new(outmap_tmp, rtype);
    if (out_fd < 0)
	G_fatal_error(_("Unable to create raster map <%s>"), outmap_tmp);

    estimated_lines = -1;

    /* allocate memory for a single row of output data */
    raster_row = G_allocate_raster_buf(rtype);

    G_message(_("Scanning data ..."));

    count_total = 0;

    /* main binning loop(s) */
    for (pass = 1; pass <= npasses; pass++) {
	if (npasses > 1)
	    G_message(_("Pass #%d (of %d) ..."), pass, npasses);

	/* figure out segmentation */
	pass_north = region.north - (pass - 1) * rows * region.ns_res;
	if (pass == npasses)
	    rows = region.rows - (pass - 1) * rows;
	pass_south = pass_north - rows * region.ns_res;

	G_debug(2, "pass=%d/%d  pass_n=%f  pass_s=%f  rows=%d",
		pass, npasses, pass_north, pass_south, rows);

	window.north = pass_north;
	window.south = pass_south;
	get_geo_bounds(window, bounds);


	if (bin_n) {
	    G_debug(2, "allocating n_array");
	    n_array = G_calloc(rows * (cols + 1), G_raster_size(CELL_TYPE));
	    blank_array(n_array, rows, cols, CELL_TYPE, 0);
	}
	if (bin_min) {
	    G_debug(2, "allocating min_array");
	    min_array = G_calloc(rows * (cols + 1), G_raster_size(rtype));
	    blank_array(min_array, rows, cols, rtype, -1);	/* fill with NULLs */
	}
	if (bin_max) {
	    G_debug(2, "allocating max_array");
	    max_array = G_calloc(rows * (cols + 1), G_raster_size(rtype));
	    blank_array(max_array, rows, cols, rtype, -1);	/* fill with NULLs */
	}
	if (bin_sum) {
	    G_debug(2, "allocating sum_array");
	    sum_array = G_calloc(rows * (cols + 1), G_raster_size(rtype));
	    blank_array(sum_array, rows, cols, rtype, 0);
	}
	if (bin_sumsq) {
	    G_debug(2, "allocating sumsq_array");
	    sumsq_array = G_calloc(rows * (cols + 1), G_raster_size(rtype));
	    blank_array(sumsq_array, rows, cols, rtype, 0);
	}
	if (bin_index) {
	    G_debug(2, "allocating index_array");
	    index_array =
		G_calloc(rows * (cols + 1), G_raster_size(CELL_TYPE));
	    blank_array(index_array, rows, cols, CELL_TYPE, -1);	/* fill with NULLs */
	}

	line = 0;
	count = 0;
	G_percent_reset();

	formatread = -1;
	status = mb_get_info_datalist(verbose, infile, &formatread,
				      &mb_info, lonflip, &error);

	if (status = mb_datalist_open(verbose, &datalist,
				      infile, look_processed,
				      &error) != MB_SUCCESS) {
	    error = MB_ERROR_OPEN_FAIL;
	    fprintf(stderr, "\nUnable to open data list file: %s\n", infile);
	    mb_memory_clear(verbose, &error);
	    exit(error);
	}

	while ((status = mb_datalist_read2(verbose, datalist,
					   &pstatus, path, ppath, &format,
					   &file_weight, &error))
	       == MB_SUCCESS) {

	    /* if format > 0 then input is swath sonar file */
	    if (format > 0 && path[0] != '#') {
		/* apply pstatus */
		if (pstatus == MB_PROCESSED_USE)
		    strcpy(file, ppath);
		else
		    strcpy(file, path);


		/* check for mbinfo file - get file bounds if possible */
		rformat = format;
		strcpy(rfile, file);
		status = mb_check_info(verbose, rfile, lonflip, bounds,
				       &file_in_bounds, &error);
		if (status == MB_FAILURE) {
		    file_in_bounds = MB_YES;
		    status = MB_SUCCESS;
		    error = MB_ERROR_NO_ERROR;
		}

		/* initialize the swath sonar file */
		if (file_in_bounds == MB_YES) {
		    /* check for "fast bathymetry" or "fbt" file */
		    if (datatype == MBGRID_DATA_TOPOGRAPHY
			|| datatype == MBGRID_DATA_BATHYMETRY) {
			mb_get_fbt(verbose, rfile, &rformat, &error);
		    }

		    /* call mb_read_init() */
		    if ((status =
			 mb_read_init(verbose, rfile, rformat, pings, lonflip,
				      bounds, btime_i, etime_i, speedmin,
				      timegap, &mbio_ptr, &btime_d, &etime_d,
				      &beams_bath, &beams_amp, &pixels_ss,
				      &error)) != MB_SUCCESS) {

			mb_error(verbose, error, &message);
			fprintf(stderr,
				"\nMultibeam File <%s> not initialized for reading\n",
				rfile);
			mb_memory_clear(verbose, &error);
			exit(error);
		    }

		    /* get mb_io_ptr */
		    mb_io_ptr = (struct mb_io_struct *)mbio_ptr;

		    /* allocate memory for reading data arrays */
		    if (error == MB_ERROR_NO_ERROR)
			status =
			    mb_register_array(verbose, mbio_ptr,
					      MB_MEM_TYPE_BATHYMETRY,
					      sizeof(char),
					      (void **)&beamflag, &error);
		    if (error == MB_ERROR_NO_ERROR)
			status =
			    mb_register_array(verbose, mbio_ptr,
					      MB_MEM_TYPE_BATHYMETRY,
					      sizeof(double), (void **)&bath,
					      &error);
		    if (error == MB_ERROR_NO_ERROR)
			status =
			    mb_register_array(verbose, mbio_ptr,
					      MB_MEM_TYPE_AMPLITUDE,
					      sizeof(double), (void **)&amp,
					      &error);
		    if (error == MB_ERROR_NO_ERROR)
			status =
			    mb_register_array(verbose, mbio_ptr,
					      MB_MEM_TYPE_BATHYMETRY,
					      sizeof(double),
					      (void **)&bathlon, &error);
		    if (error == MB_ERROR_NO_ERROR)
			status =
			    mb_register_array(verbose, mbio_ptr,
					      MB_MEM_TYPE_BATHYMETRY,
					      sizeof(double),
					      (void **)&bathlat, &error);
		    if (error == MB_ERROR_NO_ERROR)
			status =
			    mb_register_array(verbose, mbio_ptr,
					      MB_MEM_TYPE_SIDESCAN,
					      sizeof(double), (void **)&ss,
					      &error);
		    if (error == MB_ERROR_NO_ERROR)
			status =
			    mb_register_array(verbose, mbio_ptr,
					      MB_MEM_TYPE_SIDESCAN,
					      sizeof(double), (void **)&sslon,
					      &error);
		    if (error == MB_ERROR_NO_ERROR)
			status =
			    mb_register_array(verbose, mbio_ptr,
					      MB_MEM_TYPE_SIDESCAN,
					      sizeof(double), (void **)&sslat,
					      &error);

		    /* if error initializing memory then quit */
		    if (error != MB_ERROR_NO_ERROR) {
			mb_error(verbose, error, &message);
			fprintf(stderr,
				"\nMBIO Error allocating data arrays:\n%s\n",
				message);
			mb_memory_clear(verbose, &error);
			exit(error);
		    }

		    /* loop over reading */
		    cnt_file = 0;
		    while (error <= MB_ERROR_NO_ERROR) {
			status = mb_read(verbose, mbio_ptr, &kind,
					 &rpings, time_i, &time_d,
					 &navlon, &navlat,
					 &speed, &heading,
					 &distance, &altitude, &sonardepth,
					 &beams_bath, &beams_amp, &pixels_ss,
					 beamflag, bath, amp, bathlon,
					 bathlat, ss, sslon, sslat, comment,
					 &error);

			/* time gaps are not a problem here */
			if (error == MB_ERROR_TIME_GAP) {
			    error = MB_ERROR_NO_ERROR;
			    status = MB_SUCCESS;
			}

			if ((datatype == MBGRID_DATA_BATHYMETRY
			     || datatype == MBGRID_DATA_TOPOGRAPHY
			     || datatype == MBGRID_DATA_AMPLITUDE 
			     || datatype == MBGRID_DATA_SIDESCAN )
			    && error == MB_ERROR_NO_ERROR) {

			    beams_all = beams_bath;
			    if (amp_flag->answer)
				beams_all = beams_amp;
			    if (sidescan_flag->answer)
				beams_all = pixels_ss;


			    /* Nadir position */
			    if (sidescan_flag->answer)
			    {
				x_nadir = sslon[beams_all/2];
				y_nadir = sslat[beams_all/2];
			    } else {
			    	x_nadir = bathlon[beams_all/2];
			    	y_nadir = bathlat[beams_all/2];
			    }
			 if (G_projection() != PROJECTION_LL) 
			{
				if (pj_do_proj(&x_nadir, &y_nadir, &oproj, &iproj) <
                                        0)
                                        G_fatal_error(_("Error in pj_do_proj (projection of input coordinate pair)"));
			}


			 cross_dist = 0.0;

			    /* deal with data */
			    for (ib = 0; ib < beams_all; ib++) {

/** Insert here to restrict by beam number **/
/**				if (ib < 10)
					continue;
				if (ib > 50)
					continue;
**/

				if (!mb_beam_ok(beamflag[ib]) && !sidescan_flag->answer) 
				    continue;

				if (sidescan_flag->answer && ss[ib] <= MB_SIDESCAN_NULL)
					continue;


				    if (sidescan_flag->answer)
				    {
					x = sslon[ib];
					y = sslat[ib];

				    } else {
				    	x = bathlon[ib];
				    	y = bathlat[ib];
				    }

				    if (G_projection() != PROJECTION_LL) 
				    {
					if (pj_do_proj(&x, &y, &oproj, &iproj) <
					0)
					G_fatal_error(_("Error in pj_do_proj (projection of input coordinate pair)"));
				    }

				    if (y <= pass_south || y > pass_north)
					continue;
				    if (x < region.west || x > region.east)
					continue;

				cross_dist = sqrt( (x-x_nadir)*(x-x_nadir) + 
						(y-y_nadir)*(y-y_nadir) );

/** Code to restrict by acrosstrack distance **/
				if (width_opt->answer)
				{
					if (cross_dist > atof(width_opt->answer))
						continue;
				}

				    if (amp_flag->answer)
					z = amp[ib];
				    else if (sidescan_flag->answer)
					z = ss[ib];
				    else 
				    	z = bath[ib] * -1.0;	/* Topo up */
				    
				    z = z / zscale;
				    if (zrange_opt->answer) {
					if (z < zrange_min || z > zrange_max)
					    continue;
				    }

				    count++;
				    cnt_file++;

				    /* find the bin in the current array box */
				    arr_row =
					(int)((pass_north -
					       y) / region.ns_res);
				    arr_col =
					(int)((x -
					       region.west) / region.ew_res);
				    if (arr_col >= cols) {
					if (((x -
					      region.west) / region.ew_res) -
					    cols < 10 * GRASS_EPSILON)
					    arr_col--;
					else {	/* oh well, we tried. */
					    G_debug(3,
						    "skipping extraneous data point [%.3f], column %d of %d",
						    x, arr_col, cols);
					    continue;
					}
				    }

				    if (bin_n)
					update_n(n_array, cols, arr_row,
						 arr_col);
				    if (bin_min)
					update_min(min_array, cols, arr_row,
						   arr_col, rtype, z);
				    if (bin_max)
					update_max(max_array, cols, arr_row,
						   arr_col, rtype, z);
				    if (bin_sum)
					update_sum(sum_array, cols, arr_row,
						   arr_col, rtype, z);
				    if (bin_sumsq)
					update_sumsq(sumsq_array, cols,
						     arr_row, arr_col, rtype,
						     z);
				    if (bin_index) {
					ptr = index_array;
					ptr =
					    G_incr_void_ptr(ptr,
							    ((arr_row *
							      cols) +
							     arr_col) *
							    G_raster_size
							    (CELL_TYPE));

					if (G_is_null_value(ptr, CELL_TYPE)) {	/* first node */
					    head_id = new_node();
					    nodes[head_id].next = -1;
					    nodes[head_id].z = z;
					    G_set_raster_value_c(ptr, head_id, CELL_TYPE);	/* store index to head */
					}
					else {	/* head is already there */

					    head_id = G_get_raster_value_c(ptr, CELL_TYPE);	/* get index to head */
					    head_id = add_node(head_id, z);
					    if (head_id != -1)
						G_set_raster_value_c(ptr, head_id, CELL_TYPE);	/* store index to head */
					}
				    }
			    }

			}

		    }

		    /* Done with file */
		    fprintf(stderr, "Read %d in %s\n", cnt_file, rfile);
		    status = mb_close(verbose, &mbio_ptr, &error);
		    status = MB_SUCCESS;
		    error = MB_ERROR_NO_ERROR;
		}

	    }


	}



	G_debug(2, "pass %d finished, %d coordinates in box", pass, count);
	count_total += count;

	/* calc stats and output */
	G_message(_("Writing to map ..."));
	for (row = 0; row < rows; row++) {

	    switch (method) {
	    case METHOD_N:	/* n is a straight copy */
		G_raster_cpy(raster_row,
			     n_array +
			     (row * cols * G_raster_size(CELL_TYPE)), cols,
			     CELL_TYPE);
		break;

	    case METHOD_MIN:
		G_raster_cpy(raster_row,
			     min_array + (row * cols * G_raster_size(rtype)),
			     cols, rtype);
		break;

	    case METHOD_MAX:
		G_raster_cpy(raster_row,
			     max_array + (row * cols * G_raster_size(rtype)),
			     cols, rtype);
		break;

	    case METHOD_SUM:
		G_raster_cpy(raster_row,
			     sum_array + (row * cols * G_raster_size(rtype)),
			     cols, rtype);
		break;

	    case METHOD_RANGE:	/* (max-min) */
		ptr = raster_row;
		for (col = 0; col < cols; col++) {
		    offset = (row * cols + col) * G_raster_size(rtype);
		    min = G_get_raster_value_d(min_array + offset, rtype);
		    max = G_get_raster_value_d(max_array + offset, rtype);
		    G_set_raster_value_d(ptr, max - min, rtype);
		    ptr = G_incr_void_ptr(ptr, G_raster_size(rtype));
		}
		break;

	    case METHOD_MEAN:	/* (sum / n) */
		ptr = raster_row;
		for (col = 0; col < cols; col++) {
		    offset = (row * cols + col) * G_raster_size(rtype);
		    n_offset = (row * cols + col) * G_raster_size(CELL_TYPE);
		    n = G_get_raster_value_c(n_array + n_offset, CELL_TYPE);
		    sum = G_get_raster_value_d(sum_array + offset, rtype);

		    /* Infill if inside region */
/**
		    if (n == 0 &&
			col > fill_size / 2 && col < cols - fill_size / 2 &&
			row > fill_size / 2 && row < rows - fill_size / 2) {
			for (zz = fill_start; zz < fill_start + fill_size;
			     zz++) {
			    for (zzz = fill_start;
				 zzz < fill_start + fill_size; zzz++) {
				offset =
				    ((row + zz) * cols +
				     (col + zzz)) * G_raster_size(rtype);
				n_offset =
				    ((row + zz) * cols +
				     (col + zzz)) * G_raster_size(CELL_TYPE);
				n += G_get_raster_value_c(n_array + n_offset,
							  CELL_TYPE);
				sum +=
				    G_get_raster_value_d(sum_array + offset,
							 rtype);

			    }
			}

			if (n > 0) {
			    G_set_raster_value_d(ptr, (sum / n), rtype);
			    fill_cnt++;
			}
			else {
			    G_set_null_value(ptr, 1, rtype);
			}

		    }
		    else {
**/

			if (n == 0)
			    G_set_null_value(ptr, 1, rtype);
			else
			    G_set_raster_value_d(ptr, (sum / n), rtype);
/**
		    }
**/

		    ptr = G_incr_void_ptr(ptr, G_raster_size(rtype));
		}
		break;

	    case METHOD_STDDEV:	/*  sqrt(variance)        */
	    case METHOD_VARIANCE:	/*  (sumsq - sum*sum/n)/n */
	    case METHOD_COEFF_VAR:	/*  100 * stdev / mean    */
		ptr = raster_row;
		for (col = 0; col < cols; col++) {
		    offset = (row * cols + col) * G_raster_size(rtype);
		    n_offset = (row * cols + col) * G_raster_size(CELL_TYPE);
		    n = G_get_raster_value_c(n_array + n_offset, CELL_TYPE);
		    sum = G_get_raster_value_d(sum_array + offset, rtype);
		    sumsq = G_get_raster_value_d(sumsq_array + offset, rtype);

		    if (n == 0)
			G_set_null_value(ptr, 1, rtype);
		    else {
			variance = (sumsq - sum * sum / n) / n;
			if (variance < GRASS_EPSILON)
			    variance = 0.0;

			if (method == METHOD_STDDEV)
			    G_set_raster_value_d(ptr, sqrt(variance), rtype);

			else if (method == METHOD_VARIANCE)
			    G_set_raster_value_d(ptr, variance, rtype);

			else if (method == METHOD_COEFF_VAR)
			    G_set_raster_value_d(ptr,
						 100 * sqrt(variance) / (sum /
									 n),
						 rtype);

		    }
		    ptr = G_incr_void_ptr(ptr, G_raster_size(rtype));
		}
		break;
	    case METHOD_MEDIAN:	/* median, if only one point in cell we will use that */
		ptr = raster_row;
		for (col = 0; col < cols; col++) {
		    n_offset = (row * cols + col) * G_raster_size(CELL_TYPE);
		    if (G_is_null_value(index_array + n_offset, CELL_TYPE)) {
			/* no points in cell */
			G_set_null_value(ptr, 1, rtype);
		    }
		    else {	/* one or more points in cell */

			head_id =
			    G_get_raster_value_c(index_array + n_offset,
						 CELL_TYPE);
			node_id = head_id;

			n = 0;

			while (node_id != -1) {	/* count number of points in cell */
			    n++;
			    node_id = nodes[node_id].next;
			}

			if (n == 1)	/* only one point, use that */
			    G_set_raster_value_d(ptr, nodes[head_id].z,
						 rtype);
			else if (n % 2 != 0) {	/* odd number of points: median_i = (n + 1) / 2 */
			    n = (n + 1) / 2;
			    node_id = head_id;
			    for (j = 1; j < n; j++)	/* get "median element" */
				node_id = nodes[node_id].next;

			    G_set_raster_value_d(ptr, nodes[node_id].z,
						 rtype);
			}
			else {	/* even number of points: median = (val_below + val_above) / 2 */

			    z = (n + 1) / 2.0;
			    n = floor(z);
			    node_id = head_id;
			    for (j = 1; j < n; j++)	/* get element "below" */
				node_id = nodes[node_id].next;

			    z = (nodes[node_id].z +
				 nodes[nodes[node_id].next].z) / 2;
			    G_set_raster_value_d(ptr, z, rtype);
			}
		    }

		    ptr = G_incr_void_ptr(ptr, G_raster_size(rtype));
		}
		break;
	    case METHOD_PERCENTILE:	/* rank = (pth*(n+1))/100; interpolate linearly */
		ptr = raster_row;
		for (col = 0; col < cols; col++) {
		    n_offset = (row * cols + col) * G_raster_size(CELL_TYPE);
		    if (G_is_null_value(index_array + n_offset, CELL_TYPE))	/* no points in cell */
			G_set_null_value(ptr, 1, rtype);
		    else {
			head_id =
			    G_get_raster_value_c(index_array + n_offset,
						 CELL_TYPE);
			node_id = head_id;
			n = 0;

			while (node_id != -1) {	/* count number of points in cell */
			    n++;
			    node_id = nodes[node_id].next;
			}

			z = (pth * (n + 1)) / 100.0;
			r_low = floor(z);	/* lower rank */
			if (r_low < 1)
			    r_low = 1;
			else if (r_low > n)
			    r_low = n;

			r_up = ceil(z);	/* upper rank */
			if (r_up > n)
			    r_up = n;

			node_id = head_id;
			for (j = 1; j < r_low; j++)	/* search lower value */
			    node_id = nodes[node_id].next;

			z = nodes[node_id].z;	/* save lower value */
			node_id = head_id;
			for (j = 1; j < r_up; j++)	/* search upper value */
			    node_id = nodes[node_id].next;

			z = (z + nodes[node_id].z) / 2;
			G_set_raster_value_d(ptr, z, rtype);
		    }
		    ptr = G_incr_void_ptr(ptr, G_raster_size(rtype));
		}
		break;
	    case METHOD_SKEWNESS:	/* skewness = sum(xi-mean)^3/(N-1)*s^3 */
		ptr = raster_row;
		for (col = 0; col < cols; col++) {
		    n_offset = (row * cols + col) * G_raster_size(CELL_TYPE);
		    if (G_is_null_value(index_array + n_offset, CELL_TYPE))	/* no points in cell */
			G_set_null_value(ptr, 1, rtype);
		    else {
			head_id =
			    G_get_raster_value_c(index_array + n_offset,
						 CELL_TYPE);
			node_id = head_id;

			n = 0;	/* count */
			sum = 0.0;	/* sum */
			sumsq = 0.0;	/* sum of squares */
			sumdev = 0.0;	/* sum of (xi - mean)^3 */
			skew = 0.0;	/* skewness */

			while (node_id != -1) {
			    z = nodes[node_id].z;
			    n++;
			    sum += z;
			    sumsq += (z * z);
			    node_id = nodes[node_id].next;
			}

			if (n > 1) {	/* if n == 1, skew is "0.0" */
			    mean = sum / n;
			    node_id = head_id;
			    while (node_id != -1) {
				z = nodes[node_id].z;
				sumdev += pow((z - mean), 3);
				node_id = nodes[node_id].next;
			    }

			    variance = (sumsq - sum * sum / n) / n;
			    if (variance < GRASS_EPSILON)
				skew = 0.0;
			    else
				skew =
				    sumdev / ((n - 1) *
					      pow(sqrt(variance), 3));
			}
			G_set_raster_value_d(ptr, skew, rtype);
		    }
		    ptr = G_incr_void_ptr(ptr, G_raster_size(rtype));
		}
		break;
	    case METHOD_TRIMMEAN:
		ptr = raster_row;
		for (col = 0; col < cols; col++) {
		    n_offset = (row * cols + col) * G_raster_size(CELL_TYPE);
		    if (G_is_null_value(index_array + n_offset, CELL_TYPE))	/* no points in cell */
			G_set_null_value(ptr, 1, rtype);
		    else {
			head_id =
			    G_get_raster_value_c(index_array + n_offset,
						 CELL_TYPE);

			node_id = head_id;
			n = 0;
			while (node_id != -1) {	/* count number of points in cell */
			    n++;
			    node_id = nodes[node_id].next;
			}

			if (1 == n)
			    mean = nodes[head_id].z;
			else {
			    k = floor(trim * n + 0.5);	/* number of ranks to discard on each tail */

			    if (k > 0 && (n - 2 * k) > 0) {	/* enough elements to discard */
				node_id = head_id;
				for (j = 0; j < k; j++)	/* move to first rank to consider */
				    node_id = nodes[node_id].next;

				j = k + 1;
				k = n - k;
				n = 0;
				sum = 0.0;

				while (j <= k) {	/* get values in interval */
				    n++;
				    sum += nodes[node_id].z;
				    node_id = nodes[node_id].next;
				    j++;
				}
			    }
			    else {
				node_id = head_id;
				n = 0;
				sum = 0.0;
				while (node_id != -1) {
				    n++;
				    sum += nodes[node_id].z;
				    node_id = nodes[node_id].next;
				}
			    }
			    mean = sum / n;
			}
			G_set_raster_value_d(ptr, mean, rtype);
		    }
		    ptr = G_incr_void_ptr(ptr, G_raster_size(rtype));
		}
		break;

	    default:
		G_fatal_error("?");
	    }

	    /* write out line of raster data */
	    if (1 != G_put_raster_row(out_fd, raster_row, rtype)) {
		G_close_cell(out_fd);
		G_fatal_error(_("Writing map, row %d"),
			      ((pass - 1) * rows) + row);
	    }
	}


	/* free memory */
	if (bin_n)
	    G_free(n_array);
	if (bin_min)
	    G_free(min_array);
	if (bin_max)
	    G_free(max_array);
	if (bin_sum)
	    G_free(sum_array);
	if (bin_sumsq)
	    G_free(sumsq_array);
	if (bin_index) {
	    G_free(index_array);
	    G_free(nodes);
	    num_nodes = 0;
	    max_nodes = 0;
	    nodes = NULL;
	}

	if (datalist != NULL)
	    mb_datalist_close(verbose, &datalist, &error);

    }				/* passes loop */


    G_percent(1, 1, 1);		/* flush */
    G_free(raster_row);

    /* close raster file & write history */
    G_close_cell(out_fd);

    fprintf(stderr, "Do fill map\n");
    fill_map(outmap_tmp, outmap, fill_size, verbose);

    sprintf(title, "Mulltibeam data binned into a raster grid by cell %s",
	    method_opt->answer);
    G_put_cell_title(outmap, title);

    G_short_history(outmap, "raster", &history);
    G_command_history(&history);
    G_write_history(outmap, &history);

    sprintf(buff, _("%d points found in region."), count_total);
    G_done_msg(buff);
    G_debug(1, "Processed %d lines.", line);

    exit(EXIT_SUCCESS);

}



int scan_bounds(FILE * fp, int xcol, int ycol, int zcol, char *fs,
		int shell_style, int skipline, double zscale)
{
    int line, first, max_col;
    char buff[BUFFSIZE];
    double min_x, max_x, min_y, max_y, min_z, max_z;
    char **tokens;
    int ntokens;		/* number of tokens */
    double x, y, z;

    max_col = (xcol > ycol) ? xcol : ycol;
    max_col = (zcol > max_col) ? zcol : max_col;

    line = 0;
    first = TRUE;

    G_verbose_message(_("Scanning data ..."));

    while (0 != G_getl2(buff, BUFFSIZE - 1, fp)) {
	line++;

	if ((buff[0] == '#') || (buff[0] == '\0')) {
	    continue;		/* line is a comment or blank */
	}

	G_chop(buff);		/* remove leading and trailing whitespace. unneded?? */
	tokens = G_tokenize(buff, fs);
	ntokens = G_number_of_tokens(tokens);

	if ((ntokens < 3) || (max_col > ntokens)) {
	    if (skipline) {
		G_warning(_("Not enough data columns. "
			    "Incorrect delimiter or column number? "
			    "Found the following character(s) in row %d:\n[%s]"),
			  line, buff);
		G_warning(_("Line ignored as requested"));
		continue;	/* line is garbage */
	    }
	    else {
		G_fatal_error(_("Not enough data columns. "
				"Incorrect delimiter or column number? "
				"Found the following character(s) in row %d:\n[%s]"),
			      line, buff);
	    }
	}

	/* too slow?
	   if ( G_projection() == PROJECTION_LL ) {
	   G_scan_easting( tokens[xcol-1], &x, region.proj);
	   G_scan_northing( tokens[ycol-1], &y, region.proj);
	   }
	   else {
	 */
	if (1 != sscanf(tokens[xcol - 1], "%lf", &x))
	    G_fatal_error(_("Bad x-coordinate line %d column %d. <%s>"), line,
			  xcol, tokens[xcol - 1]);

	if (first) {
	    min_x = x;
	    max_x = x;
	}
	else {
	    if (x < min_x)
		min_x = x;
	    if (x > max_x)
		max_x = x;
	}

	if (1 != sscanf(tokens[ycol - 1], "%lf", &y))
	    G_fatal_error(_("Bad y-coordinate line %d column %d. <%s>"), line,
			  ycol, tokens[ycol - 1]);

	if (first) {
	    min_y = y;
	    max_y = y;
	}
	else {
	    if (y < min_y)
		min_y = y;
	    if (y > max_y)
		max_y = y;
	}

	if (1 != sscanf(tokens[zcol - 1], "%lf", &z))
	    G_fatal_error(_("Bad z-coordinate line %d column %d. <%s>"), line,
			  zcol, tokens[zcol - 1]);

	if (first) {
	    min_z = z;
	    max_z = z;
	    first = FALSE;
	}
	else {
	    if (z < min_z)
		min_z = z;
	    if (z > max_z)
		max_z = z;
	}


	G_free_tokens(tokens);
    }

    if (!shell_style) {
	fprintf(stderr, _("Range:     min         max\n"));
	fprintf(stdout, "x: %11f %11f\n", min_x, max_x);
	fprintf(stdout, "y: %11f %11f\n", min_y, max_y);
	fprintf(stdout, "z: %11f %11f\n", min_z / zscale, max_z / zscale);
    }
    else
	fprintf(stdout, "n=%f s=%f e=%f w=%f b=%f t=%f\n",
		max_y, min_y, max_x, min_x, min_z / zscale, max_z / zscale);

    G_debug(1, "Processed %d lines.", line);
    G_debug(1, "region template: g.region n=%f s=%f e=%f w=%f",
	    max_y, min_y, max_x, min_x);

    return 0;
}


void get_geo_bounds(struct Cell_head window, double bounds[4])
{
    double latitude, longitude;
    double lo1, la1, la2, lo2, la3, lo3, lo4, la4;
    double overlap = MB_OVERLAP/100.0;
    double height;

    latitude = window.north;
    longitude = window.west;

    if (G_projection() != PROJECTION_LL)
    {
    if (pj_do_proj(&longitude, &latitude, &iproj, &oproj) < 0)
	G_fatal_error(_("Error in pj_do_proj (projection of input coordinate pair)"));
    }

    lo1 = longitude;
    la1 = latitude;


    latitude = window.north;
    longitude = window.east;
    if (G_projection() != PROJECTION_LL)
    {
    if (pj_do_proj(&longitude, &latitude, &iproj, &oproj) < 0)
	G_fatal_error(_("Error in pj_do_proj (projection of input coordinate pair)"));
    }

    lo2 = longitude;
    la2 = latitude;

    latitude = window.south;
    longitude = window.east;
    if (G_projection() != PROJECTION_LL)
    {
    if (pj_do_proj(&longitude, &latitude, &iproj, &oproj) < 0)
	G_fatal_error(_("Error in pj_do_proj (projection of input coordinate pair)"));
    }
    lo3 = longitude;
    la3 = latitude;

    latitude = window.south;
    longitude = window.west;
    if (G_projection() != PROJECTION_LL)
    {
    if (pj_do_proj(&longitude, &latitude, &iproj, &oproj) < 0)
	G_fatal_error(_("Error in pj_do_proj (projection of input coordinate pair)"));
    }
    lo4 = longitude;
    la4 = latitude;

    if (la1 > la2)
	bounds[3] = la1;
    else
	bounds[3] = la2;

    if (la3 < la4)
	bounds[2] = la3;
    else
	bounds[2] = la4;

    if (lo1 < lo4)
	bounds[0] = lo1;
    else
	bounds[0] = lo4;

    if (lo2 > lo3)
	bounds[1] = lo2;
    else
	bounds[1] = lo3;

    /* Now add overlap */
    height = bounds[3] - bounds[2]; /* north - south */
    bounds[3] += height * overlap;
    bounds[2] -= height * overlap;

}


static 
void fill_map(char *in_name, char *out_name, double radius, int verbose)
{

        int oldval = 0;
        int newval = 0;
        char *mapset;
        RASTER_MAP_TYPE type;
        int in_fd;
        int out_fd;
        DCELL **in_rows;
        DCELL *out_row;
        int nrows, row;
        int ncols, col;

        mapset = G_find_cell(in_name, "");
        if (!mapset)
                G_fatal_error(_("Raster map <%s> not found"), in_name);

        nrows = G_window_rows();
        ncols = G_window_cols();

	setup_neighbors_euclidian(radius);

        in_fd = G_open_cell_old(in_name, mapset);
        if (in_fd < 0)
                G_fatal_error(_("Unable to open raster map <%s>"), in_name);

        type = G_get_raster_map_type(in_fd);

        out_fd = G_open_raster_new(out_name, type);
        if (out_fd < 0)
                G_fatal_error(_("Unable to create raster map <%s>"), out_name);

        in_rows = G_malloc((size * 2 + 1) * sizeof(DCELL *));

        for (row = 0; row <= size * 2; row++)
                in_rows[row] = G_allocate_d_raster_buf();

        out_row = G_allocate_d_raster_buf();

        for (row = 0; row < size; row++)
                G_get_d_raster_row(in_fd, in_rows[size + row], row);

        for (row = 0; row < nrows; row++)
        {
                DCELL *tmp;
                int i;

                if (row + size < nrows)
                        G_get_d_raster_row(in_fd, in_rows[size * 2], row + size);

                for (col = 0; col < ncols; col++)
                {
                        DCELL *c = &in_rows[size][col];

                        if (!G_is_d_null_value(c))
                        {
                                out_row[col] = *c;
                                continue;
                        }

                        for (i = 0; i < count; i++)
                        {
                                int dx = neighbors[i][0];
                                int dy = neighbors[i][1];
                                int x = col + dx;
                                int y = row + dy;

                                if (x < 0 || x >= ncols || y < 0 || y >= nrows)
                                        continue;

                                c = &in_rows[size + dy][x];

                                if (!G_is_d_null_value(c))
                                {
                                        out_row[col] = *c;
                                        break;
                                }
                        }

                        if (i == count)
                                G_set_d_null_value(&out_row[col], 1);
                }

                G_put_d_raster_row(out_fd, out_row);

                G_percent(row, nrows, 2);

                tmp = in_rows[0];
                for (i = 0; i < size * 2; i++)
                        in_rows[i] = in_rows[i + 1];
                in_rows[size * 2] = tmp;
        }

        G_percent(row, nrows, 2);

        G_close_cell(in_fd);
        G_close_cell(out_fd);

}

/*
 ****************************************************************************
 *
 * MODULE:	r.out.colorbar
 * AUTHOR:	Bob Covill - Tekmap Consulting
 * PURPOSE:	Export GRASS Raster color table as annotated colorbar
 * COPYRIGHT:	(C) 2010 by the GRASS Development Team
 *
 *               This program is free software under the GNU General Public
 *               License (>=v2). Read the file COPYING that comes with GRASS
 *               for details.
 * REQUIRES:	GTK+ lib and Cairo Graphis Lib 
 * 		http://www.cairographics.org/
 *
 *****************************************************************************/

/* 
* Program uses cairo http://www.cairographics.org/ to draw colorbar image
* Supported formats include PNG, PDF, PS
*/

#ifdef HAVE_CONFIG_H
 #include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <gtk/gtk.h>
#include <glib.h>
#include <glib/gstdio.h>
#include <grass/gis.h>

#define VALID_CHARS "1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM"
#define BORDER 10
#define TEXT_BORDER 100
#define TICK_LENGTH 4

struct gtk_raster_colorbar
{
        struct Colors color;
        gdouble min;
        gdouble max;
        gint width;
        gint height;
        gint type;
        gint breaks;
        gdouble annotate;
};
struct gtk_raster_colorbar gtk_cbar;

/* prototypes */
gdouble calculate_step(gdouble, gdouble);
void colorbar_val_to_pix(gdouble, gint *);
gint get_precision();

int main (int argc, char *argv[])
{

char *mapset;
gint red, green , blue;
gdouble dval, step;
gint i;
struct FPRange fp_range;
struct Range range;
gint prec;
gint pix;
gint txt_x, txt_y;
char buff[80];
gchar **split_name;
const gchar *filename = "colorbar.png";
gchar *grass_name;
cairo_t *cr;
cairo_surface_t *surface;
cairo_text_extents_t te;
gdouble fontsize = 12.0; /* make this an argument */
gchar *fontface = "arial"; /* make this an argument */

    struct
    {
	struct Option *input, *wid, *ht, *fmt;
	struct Flag *h;
    } parm;
    struct GModule *module;

    G_gisinit(argv[0]);

    /* Set description */
    module = G_define_module();
    module->description = ""
	"Output a raster colorbar as an image";

    parm.input = G_define_option();
    parm.input->key = "input";
    parm.input->type = TYPE_STRING;
    parm.input->required = YES;
    parm.input->multiple = NO;
    parm.input->gisprompt = "old,cell,raster";
    parm.input->description = "Name of existing raster map";

    parm.wid = G_define_option();
    parm.wid->key = "width";
    parm.wid->type = TYPE_INTEGER;
    parm.wid->required = NO;
    parm.wid->answer = "30";
    parm.wid->description = "Color bar width in pixels";

    parm.ht = G_define_option();
    parm.ht->key = "height";
    parm.ht->type = TYPE_INTEGER;
    parm.ht->required = NO;
    parm.ht->answer = "350";
    parm.ht->description = "Color bar height in pixels";

    parm.fmt = G_define_option();
    parm.fmt->key = "format";
    parm.fmt->type = TYPE_INTEGER;
    parm.fmt->required = NO;
    parm.fmt->answer = "1";
    parm.fmt->description = "Output file format(1=PNG, 2=PDF, 3=PS)";

    parm.h = G_define_flag();
    parm.h->key = 'h';
    parm.h->description = "Output horizontal colorbar (default = vertical)";


    if (G_parser(argc, argv))
        exit(-1);


	/* init struct */
	gtk_cbar.width = atoi(parm.wid->answer);
	gtk_cbar.height = atoi(parm.ht->answer);;

	grass_name = parm.input->answer;
	mapset = G_find_cell2 (grass_name, "");
	if (mapset == NULL)
        {
                G_fatal_error("Raster map not found") ;
        }
        if (G_raster_map_is_fp(grass_name, mapset))
        {
                DCELL dmin, dmax;

                /* fp */
                if (G_read_fp_range(grass_name, mapset, &fp_range) == -1) {
                        G_fatal_error("Range file not available");
                }
                G_get_fp_range_min_max(&fp_range, &dmin, &dmax);
                gtk_cbar.min = dmin;
                gtk_cbar.max = dmax;
        } else {
                CELL min, max;

                if (G_read_range(grass_name, mapset, &range) == -1) {
                        G_fatal_error("Range file not available");
                }
                G_get_range_min_max(&range, &min, &max);
                gtk_cbar.min = (gdouble)min;
                gtk_cbar.max = (gdouble)max;
		}

	G_read_colors(grass_name, mapset, &gtk_cbar.color);
	gtk_cbar.annotate = calculate_step(gtk_cbar.min, gtk_cbar.max);
	prec = get_precision();

	/* get out name */
	split_name = g_strsplit(grass_name, "@", -1);
	split_name[0] = g_strcanon(split_name[0], VALID_CHARS, '_');
	switch (atoi(parm.fmt->answer))
	{
		case 1:
			filename = g_strdup_printf("%s_colorbar.png", split_name[0]);
			break;
		case 2:
			filename = g_strdup_printf("%s_colorbar.pdf", split_name[0]);
			break;
		case 3:
			filename = g_strdup_printf("%s_colorbar.eps", split_name[0]);
			break;
		default:
			filename = g_strdup_printf("%s_colorbar.png", split_name[0]);
			break;
	}
	
	/* step = (gtk_cbar.max-gtk_cbar.min)/gtk_cbar.height; */
	/* gtk_cbar.annotate = calculate_step(gtk_cbar.min, gtk_cbar.max); */

	step = (gtk_cbar.color.cmax - gtk_cbar.color.cmin)/gtk_cbar.height;

	switch (atoi(parm.fmt->answer))
	{
		case 1:
			if (parm.h->answer)
				surface = cairo_image_surface_create( CAIRO_FORMAT_ARGB32,
	                		(double)(gtk_cbar.height+(BORDER*2)),
                			(double)(gtk_cbar.width+(BORDER+TEXT_BORDER)) );
			else
				surface = cairo_image_surface_create( CAIRO_FORMAT_ARGB32,
        				(double)(gtk_cbar.width+BORDER+TEXT_BORDER),
        				(double)(gtk_cbar.height+(BORDER*2)));
			break;
		case 2:
			if (parm.h->answer)
				surface = cairo_pdf_surface_create(filename,
	                		(double)(gtk_cbar.height+(BORDER*2)),
                			(double)(gtk_cbar.width+(BORDER+TEXT_BORDER)) );
			else
				surface = cairo_pdf_surface_create(filename, 
        				(double)(gtk_cbar.width+BORDER+TEXT_BORDER),
        				(double)(gtk_cbar.height+(BORDER*2)));
			break;
		case 3:
			if (parm.h->answer)
				surface = cairo_ps_surface_create(filename,
	                		(double)(gtk_cbar.height+(BORDER*2)),
                			(double)(gtk_cbar.width+(BORDER+TEXT_BORDER)) );
			else
				surface = cairo_ps_surface_create(filename, 
        				(double)(gtk_cbar.width+BORDER+TEXT_BORDER),
        				(double)(gtk_cbar.height+(BORDER*2)));

			cairo_ps_surface_set_eps(surface, TRUE); /*output eps*/
			if (!cairo_ps_surface_get_eps(surface))
				fprintf(stderr, "Failed to assign EPS output\nDefaulting to standard Postscript\n");
			
			break;
		default:
			if (parm.h->answer)
				surface = cairo_image_surface_create( CAIRO_FORMAT_ARGB32,
	                		(double)(gtk_cbar.height+(BORDER*2)),
                			(double)(gtk_cbar.width+(BORDER+TEXT_BORDER)) );
			else
				surface = cairo_image_surface_create( CAIRO_FORMAT_ARGB32,
        				(double)(gtk_cbar.width+BORDER+TEXT_BORDER),
        				(double)(gtk_cbar.height+(BORDER*2)));
			break;
	}
	cr = cairo_create(surface);

	/* draw outline */
	cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
	cairo_set_line_width(cr, 1.5);
	if (parm.h->answer)
		cairo_rectangle (cr, (double)BORDER, (double)BORDER,
			(double)gtk_cbar.height, (double)gtk_cbar.width);
	else
		cairo_rectangle (cr, (double)BORDER, (double)BORDER,
        		(double)gtk_cbar.width, (double)gtk_cbar.height);
	cairo_stroke (cr);

	/* draw colors */
	for (i = 0; i < gtk_cbar.height; i++)
	{
		dval = (gtk_cbar.color.cmax - (i * step));
		G_get_d_raster_color(&dval, &red, &green, &blue, 
			&gtk_cbar.color);
		cairo_set_line_width(cr, 0.0);
		cairo_set_source_rgb(cr, (gdouble)(red/255.0),
                	(gdouble)(green/255.0), (gdouble)(blue/255.0) );

		if (parm.h->answer)
			cairo_rectangle (cr, (double)(i+BORDER), (double)BORDER,                        	(double)1.0, (double)gtk_cbar.width);
		else
			cairo_rectangle (cr, (double)BORDER, (double)(i+BORDER),
                		(double)gtk_cbar.width, (double)1.0);
                
		cairo_fill (cr);

	}
	
	dval = gtk_cbar.annotate * round(gtk_cbar.color.cmax/gtk_cbar.annotate);
        if (dval > gtk_cbar.color.cmax)
                dval -= gtk_cbar.annotate;

	cairo_set_line_width(cr, 1.5);
	cairo_set_source_rgb(cr, 0.0, 0.0, 0.0); /* black */
	cairo_select_font_face(cr, fontface, 
		CAIRO_FONT_SLANT_NORMAL,
		CAIRO_FONT_WEIGHT_NORMAL);
	cairo_set_font_size(cr, fontsize);
        while (dval >= gtk_cbar.color.cmin)
        {
                sprintf(buff, "%.*lf", prec, dval);
                colorbar_val_to_pix(dval, &pix);

                /* cairo_move_to (cr, gtk_cbar.width+BORDER+2, pix); */
		cairo_text_extents (cr, buff, &te);

		if (parm.h->answer)
			 cairo_move_to (cr,
				pix - te.width / 2,
                        	gtk_cbar.width+BORDER+TICK_LENGTH+2+te.height);
		else
			cairo_move_to (cr, 
				gtk_cbar.width+BORDER+TICK_LENGTH+2,
				pix + te.height / 2);
                cairo_show_text (cr, buff); /* draw text */

		if (parm.h->answer)
		{
			cairo_move_to (cr, pix, gtk_cbar.width+BORDER);
			cairo_line_to(cr, pix, gtk_cbar.width+BORDER+TICK_LENGTH);
		} else {
			cairo_move_to (cr, gtk_cbar.width+BORDER, pix);
			cairo_line_to(cr, gtk_cbar.width+BORDER+TICK_LENGTH, pix);
		}
		cairo_stroke(cr);

                dval -= gtk_cbar.annotate;
        }
        
cairo_destroy (cr);
if (atoi(parm.fmt->answer) == 1)
	cairo_surface_write_to_png (surface, filename);
cairo_surface_destroy (surface);
g_strfreev(split_name);


    exit(0);

}

/******************************************************
 * Get decimal number precision
******************************************************/
gint
get_precision()
{
gint prec;

        gdouble df = gtk_cbar.max - gtk_cbar.min;
        if (df < .1)
                prec = 4;
        else if (df < 1.0)
                prec = 3;
        else if (df < 10.0)
                prec = 2;
        else if (df < 100.0)
                prec = 1;
        else
                prec = 1;

	return prec;
}



/*****************************************************
 * Calculate number of annotation steps
*******************************************************/
gdouble
calculate_step(gdouble min, gdouble max)
{
gdouble inc, step, val, new_val;

inc = 4.0;
step= ((max - min) / inc);

if (step < 1.0)
{
        val = 1.0;
        while ( (val * 0.5) > step)
        {
                new_val = val / 10.0;
                val /= 2.0;
                if ( (val *0.5) > step)
                        val /= 2.0;
                if ( (val * 0.5) > step)
                        val = new_val;
        }
} else {
        val = 1.0;
        while ( (val * 2.0) <= step)
        {
                new_val = val * 10.0;
                val *= 2.5;
                if ( (val * 2.0) <= step)
                        val *= 2.0;
                if ( (val * 2.0) <= step)
                        val = new_val;
                if (val == 2.5)
                        val = 3.0;
        }
}

return val;
}

/*************************************************
 * Takes depth value and return pixel location
 * on colorbar
**************************************************/
void colorbar_val_to_pix(gdouble val, gint * pix)
{
    gdouble step =
        (gtk_cbar.color.cmax - gtk_cbar.color.cmin) / gtk_cbar.height;


    *pix = (int)((gtk_cbar.color.cmax - val) / step);
    *pix += BORDER;
}
